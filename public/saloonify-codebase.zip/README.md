# Saloonify — Salon Operations & Management System

Saloonify is a modern salon management web application inspired by the business workflow of [Salonify](https://www.salonify.in/). It empowers salon and spa owners to oversee daily operations through a single, responsive dashboard: appointment scheduling, GST billing and point-of-sale (POS) with printing (A4 and 80mm thermal receipts), client directories, inventory tracking with stock-movement logs, operating expense tracking, staff rosters, and financial analytics.

---

## Architecture Overview

- **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide icons, Vite.
- **Backend**: Node.js, Express REST API, JWT authentication, bcrypt password hashing.
- **Database Layer**:
  - **MySQL Community Server** (MySQL 8.0+ or MariaDB 10.5+) is the **sole source of truth** for all application data.
  - Automatically executes table creation DDL (`users`, `staff`, `customers`, `services`, `appointments`, `invoices`, `products`, `inventory_movements`, `expenses`, `settings`).
  - Parameterized SQL queries with ACID transactions for billing, inventory deductions, and customer statistics.
  - No fake demo seeding: begins with a clean, pristine state ready for genuine business data.
  - Secure, one-time first administrator onboarding.

---

## Local Setup & Configuration (Windows & VS Code)

Follow these steps to set up and run Saloonify on Windows using Visual Studio Code and MySQL.

### Step 1: Install Node.js
1. Visit [nodejs.org](https://nodejs.org/) and download the **LTS (Long Term Support)** installer for Windows (x64).
2. Run the `.msi` setup wizard, accept terms, and click Next through defaults (ensure "Add to PATH" is checked).
3. Open Windows PowerShell or Command Prompt and verify:
   ```cmd
   node -v
   npm -v
   ```

### Step 2: Install & Start MySQL Community Server
1. Download the **MySQL Installer for Windows** from [dev.mysql.com/downloads/installer/](https://dev.mysql.com/downloads/installer/).
2. Choose the **mysql-installer-community** package.
3. Run the installer:
   - Select **Developer Default** or **Server only**.
   - In "Type and Networking", leave default port **3306**.
   - Set your **MySQL Root Password** (e.g. `Pothumm@n1` or your preferred password).
   - In "Windows Service", ensure "Start the MySQL Server at System Startup" is checked (Service Name: `MySQL80` or `MySQL`).
4. In MySQL command line client or Workbench, ensure the `saloonify` database exists:
   ```sql
   CREATE DATABASE IF NOT EXISTS saloonify;
   ```
5. Ensure the MySQL service is running:
   ```cmd
   net start MySQL80
   ```

### Step 3: Open in Visual Studio Code
1. Open Visual Studio Code.
2. Open the project folder (`File > Open Folder...`).
3. Open the integrated terminal (`Ctrl + ~` or `Terminal > New Terminal`).

### Step 4: Configure Environment Variables
Create a `.env` file in the project root by copying `.env.example`:
```cmd
copy .env.example .env
```
Inside `.env`, configure your MySQL credentials:
```env
PORT=3000

# MySQL Database Configuration
MYSQL_HOST="127.0.0.1"
MYSQL_PORT=3306
MYSQL_USER="root"
MYSQL_PASSWORD="your_mysql_password_here"
MYSQL_DATABASE="saloonify"

# Authentication Token Secret
JWT_SECRET="saloonify-production-secure-jwt-key-2026"
```

### Step 5: Install Dependencies
Run npm install in the terminal:
```cmd
npm install
```
*(Peer dependency resolution note: esbuild is managed automatically by Vite and tsx, eliminating any ERESOLVE peer conflicts).*

### Step 6: Start the Application
Run the development command:
```cmd
npm run dev
```
This boots the Express backend server on port 3000 with Vite middleware mounted, serving both frontend and backend seamlessly on `http://localhost:3000`.

### Step 7: Initial First-Time Administrator Onboarding
1. Navigate to `http://localhost:3000` in your web browser.
2. Since the database starts clean with no demo users, Saloonify automatically presents the **Initial Salon Setup** screen.
3. Enter your Salon Name, Administrator Name, Work Email, Phone, and a secure Master Password (min. 6 characters).
4. Click **Create Admin Account & Launch**. This initializes your administrator credentials in MySQL and immediately signs you in to your dashboard!
5. From the **Staff Management** console, you can subsequently invite stylists and managers.

---

## Application Modules & Business Features

### 1. Operations Dashboard
- Real-time today's sales figure (₹) with settled invoice counter.
- Today's appointment counter, completed vs upcoming ratio.
- 7-day revenue trend chart with monospace tabular figures.
- Today's upcoming client queue with direct "Bill at POS" shortcut.
- Clean zero statistics and helpful empty states when starting fresh.

### 2. Point of Sale & Billing (POS)
- Authoritative server-side calculation engine for subtotals, item discounts, invoice discounts, CGST (half rate), SGST (half rate), round-off, and grand total.
- Fast service & retail product catalog with category filters and search.
- Client selection with inline "+ Quick Add Customer" drawer saved directly to MySQL.
- Payment modes: UPI/QR, Cash, Card/POS, Split/Mixed.
- Print invoice engine supporting:
  - **A4 Full Tax Invoice** (detailed tax breakdown, salon address, GSTIN, HSN/SAC, customer details, terms).
  - **80mm Thermal Receipt** (compact layout for thermal receipt printers).

### 3. Appointment Scheduling
- Interactive appointment calendar and schedule view.
- Date navigation (Today, Prev, Next, date picker).
- Stylist assignment and conflict detection: checks for existing overlapping bookings for the stylist and warns the operator.
- Status workflows: `Booked`, `Confirmed`, `In Progress`, `Completed`, `Cancelled`, `No Show`.
- One-click "Bill at POS" converts any appointment into a completed invoice.

### 4. Customer Directory
- Search by customer name, phone number, or email.
- Duplicate phone prevention.
- Detailed customer profile drawer showing full visit history, past invoices, styling preferences, and scalp/skin notes.

### 5. Services & Pricing Menu
- Categorized treatments: Hair Styling, Hair Care, Hair Color, Facials, Spa, Nail Care, Men Grooming.
- Duration tracking (minutes), price in ₹ INR, and GST tax rate %.
- Active/Inactive availability toggles.

### 6. Staff & Stylist Management
- Profile details, phone, designations, and commission %.
- Shift timings and weekly working days schedule.
- Performance statistics: total appointments completed and revenue generated.

### 7. Inventory & Retail
- Stock level tracking with low-stock warning threshold alerts.
- Stock movements audit log (`purchase`, `internal_use`, `sale`, `adjustment`).
- Inventory cost valuation vs retail selling potential.
- Automatic stock deduction upon POS billing in database transaction.

### 8. Expense Management
- Record operational overheads: Rent, Electricity & Water, Staff Salaries, Supplies, Marketing, Hospitality.
- Vendor details, voucher/receipt numbers, payment methods.

### 9. Analytics & Reports
- Date range filtering (All time, This Month, Last Month, Custom).
- Authoritative P&L breakdown: Gross Revenue - Cost of Goods - Operating Expenses = Net Profit.
- GST liability summary (CGST + SGST).
- One-click **CSV Report Export** for bookkeeping and tax filing.

---

## License
MIT. Built for modern salons, spas, and styling studios.
