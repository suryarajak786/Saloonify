import React, { useState, useEffect } from 'react';
import { Customer, Service, Staff, Product, Invoice, Settings, Appointment } from '../types';
import { api } from '../services/api';
import {
  Search,
  Plus,
  Trash2,
  Printer,
  Receipt,
  UserPlus,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  ShoppingBag,
  Scissors,
  CreditCard,
  QrCode,
  Banknote,
  RotateCcw
} from 'lucide-react';
import { PrintableInvoice } from '../components/PrintableInvoice';

interface PosBillingPageProps {
  initialAppointment?: Appointment | null;
  onClearInitialAppointment?: () => void;
}

interface CartItem {
  itemId: string;
  itemType: 'service' | 'product';
  name: string;
  category: string;
  quantity: number;
  unitPrice: number;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  taxRate: number;
}

export const PosBillingPage: React.FC<PosBillingPageProps> = ({
  initialAppointment,
  onClearInitialAppointment
}) => {
  const [activeTab, setActiveTab] = useState<'pos' | 'history'>('pos');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);

  // POS State
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [selectedStaffId, setSelectedStaffId] = useState<string>('');
  const [appointmentId, setAppointmentId] = useState<string>('');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [overallDiscountType, setOverallDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [overallDiscountValue, setOverallDiscountValue] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card' | 'mixed'>('upi');
  const [paidAmount, setPaidAmount] = useState<string>('');
  const [billingNotes, setBillingNotes] = useState<string>('');

  // Search & Catalog Filter
  const [catalogType, setCatalogType] = useState<'services' | 'products'>('services');
  const [catalogCategory, setCatalogCategory] = useState<string>('All');
  const [catalogSearch, setCatalogSearch] = useState<string>('');
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [historySearch, setHistorySearch] = useState<string>('');

  // Modals & States
  const [showNewCustomerModal, setShowNewCustomerModal] = useState<boolean>(false);
  const [newCustName, setNewCustName] = useState<string>('');
  const [newCustPhone, setNewCustPhone] = useState<string>('');
  const [newCustEmail, setNewCustEmail] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [savedInvoiceForPrint, setSavedInvoiceForPrint] = useState<Invoice | null>(null);

  // Load Initial Data
  const loadData = async () => {
    try {
      const [custRes, servRes, prodRes, stfRes, settRes, invRes] = await Promise.all([
        api.getCustomers(),
        api.getServices({ activeOnly: true }),
        api.getInventory(),
        api.getStaff(),
        api.getSettings(),
        api.getInvoices()
      ]);

      if (custRes.success) setCustomers(custRes.customers);
      if (servRes.success) setServices(servRes.services);
      if (prodRes.success) setProducts(prodRes.products);
      if (stfRes.success) setStaffList(stfRes.staff);
      if (settRes.success) setSettings(settRes.settings);
      if (invRes.success) setInvoices(invRes.invoices);
    } catch (err: any) {
      console.error('Error loading POS data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Pre-fill from initial appointment if passed
  useEffect(() => {
    if (initialAppointment && customers.length && services.length) {
      setSelectedCustomerId(initialAppointment.customerId);
      setSelectedStaffId(initialAppointment.staffId);
      setAppointmentId(initialAppointment._id);

      const items: CartItem[] = initialAppointment.services.map((s) => {
        const fullService = services.find((srv) => srv._id === s.serviceId);
        return {
          itemId: s.serviceId,
          itemType: 'service',
          name: s.name,
          category: fullService?.category || 'Hair Styling',
          quantity: 1,
          unitPrice: s.price,
          discountType: 'percentage',
          discountValue: 0,
          taxRate: fullService?.taxRate || 18,
        };
      });

      setCartItems(items);
      setActiveTab('pos');
      if (onClearInitialAppointment) {
        onClearInitialAppointment();
      }
    }
  }, [initialAppointment, customers, services]);

  // Calculations (Mirroring backend authoritative formula)
  const calculateTotals = () => {
    let grossTotal = 0;
    let itemDiscountsTotal = 0;
    let taxableTotal = 0;
    let taxTotal = 0;

    cartItems.forEach((it) => {
      const lineGross = it.quantity * it.unitPrice;
      grossTotal += lineGross;

      let itemDisc = 0;
      if (it.discountType === 'fixed') {
        itemDisc = Math.min(it.discountValue || 0, lineGross);
      } else {
        itemDisc = (lineGross * Math.min(Math.max(it.discountValue || 0, 0), 100)) / 100;
      }
      itemDiscountsTotal += itemDisc;

      const lineTaxable = Math.max(0, lineGross - itemDisc);
      taxableTotal += lineTaxable;
      const rate = it.taxRate || 18;
      taxTotal += (lineTaxable * rate) / 100;
    });

    const preTaxSubtotal = grossTotal - itemDiscountsTotal;
    let billDiscount = 0;
    if (overallDiscountType === 'fixed') {
      billDiscount = Math.min(overallDiscountValue || 0, preTaxSubtotal);
    } else {
      billDiscount = (preTaxSubtotal * Math.min(Math.max(overallDiscountValue || 0, 0), 100)) / 100;
    }

    const finalDiscount = itemDiscountsTotal + billDiscount;
    const finalTaxable = Math.max(0, grossTotal - finalDiscount);
    const exactGrandTotal = finalTaxable + taxTotal;
    const grandTotal = Math.round(exactGrandTotal);
    const roundOff = Number((grandTotal - exactGrandTotal).toFixed(2));

    return {
      subtotal: grossTotal,
      discountAmount: Number(finalDiscount.toFixed(2)),
      taxableAmount: Number(finalTaxable.toFixed(2)),
      totalTax: Number(taxTotal.toFixed(2)),
      cgstTotal: Number((taxTotal / 2).toFixed(2)),
      sgstTotal: Number((taxTotal / 2).toFixed(2)),
      grandTotal,
      roundOff,
    };
  };

  const totals = calculateTotals();

  // Add Item to Cart
  const handleAddToCart = (item: Service | Product, type: 'service' | 'product') => {
    const existingIndex = cartItems.findIndex((c) => c.itemId === item._id && c.itemType === type);
    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      setCartItems(updated);
    } else {
      setCartItems([
        ...cartItems,
        {
          itemId: item._id,
          itemType: type,
          name: item.name,
          category: item.category,
          quantity: 1,
          unitPrice: type === 'service' ? (item as Service).price : (item as Product).sellingPrice,
          discountType: 'percentage',
          discountValue: 0,
          taxRate: item.taxRate || 18,
        },
      ]);
    }
  };

  const handleUpdateItemQty = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    const updated = [...cartItems];
    updated[index].quantity = newQty;
    setCartItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    setCartItems(cartItems.filter((_, idx) => idx !== index));
  };

  const handleResetPos = () => {
    setSelectedCustomerId('');
    setSelectedStaffId('');
    setAppointmentId('');
    setCartItems([]);
    setOverallDiscountValue(0);
    setPaidAmount('');
    setBillingNotes('');
    setFeedback(null);
  };

  // Create Quick Customer
  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName || !newCustPhone) return;

    try {
      const res = await api.createCustomer({
        name: newCustName,
        phone: newCustPhone,
        email: newCustEmail,
        gender: 'female',
      });
      if (res.success) {
        setCustomers([...customers, res.customer]);
        setSelectedCustomerId(res.customer._id);
        setShowNewCustomerModal(false);
        setNewCustName('');
        setNewCustPhone('');
        setNewCustEmail('');
        setFeedback({ type: 'success', message: `Customer ${res.customer.name} added and selected!` });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to create customer' });
    }
  };

  // Submit Invoice to Backend
  const handleSubmitInvoice = async () => {
    if (!selectedCustomerId) {
      setFeedback({ type: 'error', message: 'Please select a customer for this bill.' });
      return;
    }
    if (cartItems.length === 0) {
      setFeedback({ type: 'error', message: 'Cart is empty. Add at least one service or retail product.' });
      return;
    }

    try {
      setIsSubmitting(true);
      setFeedback(null);

      const effectivePaidAmount = paidAmount !== '' ? Number(paidAmount) : totals.grandTotal;

      const payload = {
        customerId: selectedCustomerId,
        staffId: selectedStaffId || undefined,
        appointmentId: appointmentId || undefined,
        items: cartItems,
        overallDiscountValue,
        overallDiscountType,
        paymentMethod,
        paidAmount: effectivePaidAmount,
        notes: billingNotes,
      };

      const res = await api.createInvoice(payload);
      if (res.success) {
        setSavedInvoiceForPrint(res.invoice);
        handleResetPos();
        loadData(); // reload invoices and stock
      }
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to generate tax invoice.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter Catalog
  const categories =
    catalogType === 'services'
      ? ['All', ...Array.from(new Set(services.map((s) => s.category)))]
      : ['All', ...Array.from(new Set(products.map((p) => p.category)))];

  const filteredCatalog =
    catalogType === 'services'
      ? services.filter((s) => {
          const matchCat = catalogCategory === 'All' || s.category === catalogCategory;
          const matchQ =
            !catalogSearch ||
            s.name.toLowerCase().includes(catalogSearch.toLowerCase()) ||
            s.category.toLowerCase().includes(catalogSearch.toLowerCase());
          return matchCat && matchQ;
        })
      : products.filter((p) => {
          const matchCat = catalogCategory === 'All' || p.category === catalogCategory;
          const matchQ =
            !catalogSearch ||
            p.name.toLowerCase().includes(catalogSearch.toLowerCase()) ||
            p.category.toLowerCase().includes(catalogSearch.toLowerCase()) ||
            p.sku.toLowerCase().includes(catalogSearch.toLowerCase());
          return matchCat && matchQ;
        });

  // Filter History Invoices
  const filteredInvoices = invoices.filter((inv) => {
    if (!historySearch) return true;
    const q = historySearch.toLowerCase();
    return (
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.customerName.toLowerCase().includes(q) ||
      inv.customerPhone.includes(q)
    );
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Tab Switcher */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('pos')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'pos'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Billing Terminal / POS
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'history'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Printer className="w-4 h-4" />
            Invoice History ({invoices.length})
          </button>
        </div>

        {appointmentId && (
          <span className="text-xs bg-sky-50 text-sky-800 font-medium px-2.5 py-1 rounded-md border border-sky-200">
            Billing for Appointment #{appointmentId}
          </span>
        )}
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-center justify-between ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600">
            &times;
          </button>
        </div>
      )}

      {activeTab === 'pos' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* LEFT: Item Catalog (7 cols) */}
          <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            {/* Catalog Type & Search */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center bg-slate-100 p-1 rounded-lg w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => {
                    setCatalogType('services');
                    setCatalogCategory('All');
                  }}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 ${
                    catalogType === 'services'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Scissors className="w-3.5 h-3.5 text-sky-600" />
                  Services ({services.length})
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCatalogType('products');
                    setCatalogCategory('All');
                  }}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1.5 ${
                    catalogType === 'products'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-sky-600" />
                  Retail Products ({products.length})
                </button>
              </div>

              {/* Search */}
              <div className="relative w-full sm:w-56">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder={`Search ${catalogType}...`}
                  value={catalogSearch}
                  onChange={(e) => setCatalogSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                />
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCatalogCategory(cat)}
                  className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors text-[11px] font-medium ${
                    catalogCategory === cat
                      ? 'bg-sky-100 text-sky-800 font-semibold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Catalog Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[520px] overflow-y-auto pr-1">
              {filteredCatalog.map((item: any) => (
                <div
                  key={item._id}
                  onClick={() => handleAddToCart(item, catalogType === 'services' ? 'service' : 'product')}
                  className="p-3 rounded-lg border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 cursor-pointer transition-all flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex justify-between items-start gap-2">
                      <span className="font-semibold text-slate-900 text-xs leading-snug group-hover:text-sky-700">
                        {item.name}
                      </span>
                      <span className="text-xs font-bold text-slate-900 font-mono tabular-nums shrink-0">
                        ₹{catalogType === 'services' ? item.price : item.sellingPrice}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                      {catalogType === 'services' ? (
                        <span>{item.durationMinutes} mins · {item.category}</span>
                      ) : (
                        <span>Stock: {item.stockQuantity} {item.unit} · {item.category}</span>
                      )}
                    </div>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span>GST {item.taxRate}%</span>
                    <span className="text-sky-600 font-medium group-hover:underline flex items-center gap-1">
                      <Plus className="w-3 h-3" /> Add
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT: Register & Invoice Builder (5 cols) */}
          <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            {/* Customer & Staff Selectors */}
            <div className="space-y-3 pb-3 border-b border-slate-200">
              {/* Customer */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-semibold text-slate-700">Customer *</label>
                  <button
                    type="button"
                    onClick={() => setShowNewCustomerModal(true)}
                    className="text-[11px] text-sky-600 font-medium hover:underline flex items-center gap-1"
                  >
                    <UserPlus className="w-3 h-3" /> Quick Add
                  </button>
                </div>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                >
                  <option value="">-- Choose Existing Customer --</option>
                  {customers.map((c) => (
                    <option key={c._id} value={c._id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              {/* Staff / Attendant */}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Stylist / Attendant</label>
                <select
                  value={selectedStaffId}
                  onChange={(e) => setSelectedStaffId(e.target.value)}
                  className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                >
                  <option value="">-- Assign Stylist (Optional) --</option>
                  {staffList.map((s) => (
                    <option key={s._id} value={s._id}>
                      {s.name} ({s.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Cart Items List */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-900">Current Bill Items ({cartItems.length})</span>
                {cartItems.length > 0 && (
                  <button
                    type="button"
                    onClick={handleResetPos}
                    className="text-[11px] text-rose-600 hover:underline flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Clear Cart
                  </button>
                )}
              </div>

              <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                {cartItems.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-400 italic">
                    Cart is empty. Click services or products from catalog to add.
                  </div>
                ) : (
                  cartItems.map((item, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between text-xs gap-2">
                      <div className="flex-1 truncate">
                        <div className="font-semibold text-slate-800 truncate">{item.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          ₹{item.unitPrice} each · GST {item.taxRate}%
                        </div>
                      </div>

                      {/* Qty Controls */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleUpdateItemQty(idx, item.quantity - 1)}
                          className="w-5 h-5 rounded-sm bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold"
                        >
                          -
                        </button>
                        <span className="w-6 text-center font-mono font-semibold tabular-nums">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => handleUpdateItemQty(idx, item.quantity + 1)}
                          className="w-5 h-5 rounded-sm bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold"
                        >
                          +
                        </button>
                      </div>

                      <div className="w-16 text-right font-mono font-bold text-slate-900 tabular-nums shrink-0">
                        ₹{(item.quantity * item.unitPrice).toLocaleString('en-IN')}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="text-slate-300 hover:text-rose-500 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Bill Level Discount */}
            <div className="pt-2 border-t border-slate-200 text-xs space-y-2">
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-600 font-medium">Invoice Discount</span>
                <div className="flex items-center gap-1">
                  <select
                    value={overallDiscountType}
                    onChange={(e: any) => setOverallDiscountType(e.target.value)}
                    className="p-1 text-xs border border-slate-200 rounded-md bg-slate-50"
                  >
                    <option value="percentage">%</option>
                    <option value="fixed">₹</option>
                  </select>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={overallDiscountValue || ''}
                    onChange={(e) => setOverallDiscountValue(Number(e.target.value))}
                    className="w-16 p-1 text-xs text-right border border-slate-200 rounded-md bg-slate-50 font-mono"
                  />
                </div>
              </div>

              {/* Subtotal, Tax and Total summary */}
              <div className="bg-slate-50 p-3 rounded-lg space-y-1.5 text-xs border border-slate-100">
                <div className="flex justify-between text-slate-600">
                  <span>Gross Subtotal:</span>
                  <span className="font-mono tabular-nums">₹{totals.subtotal.toLocaleString('en-IN')}</span>
                </div>
                {totals.discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Discount:</span>
                    <span className="font-mono tabular-nums">-₹{totals.discountAmount.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Taxable Value:</span>
                  <span className="font-mono tabular-nums">₹{totals.taxableAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>GST (CGST 9% + SGST 9%):</span>
                  <span className="font-mono tabular-nums">+₹{totals.totalTax.toLocaleString('en-IN')}</span>
                </div>
                {totals.roundOff !== 0 && (
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>Round-off:</span>
                    <span className="font-mono tabular-nums">{totals.roundOff}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-bold text-slate-900 border-t border-slate-200 pt-1.5">
                  <span>Payable Total:</span>
                  <span className="font-mono text-sky-700 tabular-nums">₹{totals.grandTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Payment Method</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: 'upi', label: 'UPI / QR', icon: QrCode },
                    { id: 'cash', label: 'Cash', icon: Banknote },
                    { id: 'card', label: 'Card / POS', icon: CreditCard },
                    { id: 'mixed', label: 'Split', icon: Receipt },
                  ].map((pm) => {
                    const Icon = pm.icon;
                    return (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setPaymentMethod(pm.id as any)}
                        className={`p-2 rounded-lg border text-center flex flex-col items-center gap-1 transition-all text-[11px] font-medium ${
                          paymentMethod === pm.id
                            ? 'border-sky-500 bg-sky-50 text-sky-800 font-bold'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{pm.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Amount Paid (Optional partial payment) */}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Received Amount (₹) <span className="text-slate-400 font-normal">(Leave blank for exact total)</span>
                </label>
                <input
                  type="number"
                  placeholder={`Exact: ₹${totals.grandTotal}`}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500 font-mono"
                />
              </div>

              {/* Action: Settle & Issue Invoice */}
              <button
                type="button"
                onClick={handleSubmitInvoice}
                disabled={isSubmitting || cartItems.length === 0}
                className="w-full py-3 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 mt-3"
              >
                {isSubmitting ? (
                  <span>Generating Tax Invoice...</span>
                ) : (
                  <>
                    <Printer className="w-4 h-4" />
                    <span>Complete Sale & Print Bill (₹{totals.grandTotal.toLocaleString('en-IN')})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* ==========================================
           TAB 2: PREVIOUS INVOICES HISTORY
           ========================================== */
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <h3 className="text-sm font-bold text-slate-900">Settled Invoices Ledger</h3>
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search bill #, customer, phone..."
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 bg-slate-50">
                  <th className="py-2.5 px-4 font-semibold">Invoice #</th>
                  <th className="py-2.5 px-4 font-semibold">Date & Time</th>
                  <th className="py-2.5 px-4 font-semibold">Customer</th>
                  <th className="py-2.5 px-4 font-semibold">Stylist</th>
                  <th className="py-2.5 px-4 font-semibold">Items</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Taxable</th>
                  <th className="py-2.5 px-4 font-semibold text-right">GST</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Grand Total</th>
                  <th className="py-2.5 px-4 font-semibold text-center">Payment</th>
                  <th className="py-2.5 px-4 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                {filteredInvoices.map((inv) => (
                  <tr key={inv._id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-4 font-bold text-sky-700">{inv.invoiceNumber}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans">
                      {new Date(inv.date).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-900">
                      {inv.customerName}
                      <span className="block text-[10px] text-slate-400 font-mono">{inv.customerPhone}</span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans">{inv.staffName || '-'}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans max-w-[180px] truncate">
                      {inv.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}
                    </td>
                    <td className="py-2.5 px-4 text-right tabular-nums">₹{inv.taxableAmount.toLocaleString('en-IN')}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums text-slate-500">₹{inv.totalTax.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-right font-bold text-slate-900 tabular-nums">
                      ₹{inv.grandTotal.toLocaleString('en-IN')}
                    </td>
                    <td className="py-2.5 px-4 text-center font-sans">
                      <span className="uppercase text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {inv.paymentMethod}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => setSavedInvoiceForPrint(inv)}
                        className="p-1.5 text-slate-500 hover:text-sky-600 hover:bg-slate-100 rounded-md transition-colors"
                        title="Print / View"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* QUICK ADD CUSTOMER MODAL */}
      {showNewCustomerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-2xs p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Add New Customer</h3>
            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maya Krishnan"
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Phone Number *</label>
                <input
                  type="text"
                  required
                  placeholder="+91 98..."
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500 font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Email (Optional)</label>
                <input
                  type="email"
                  placeholder="client@gmail.com"
                  value={newCustEmail}
                  onChange={(e) => setNewCustEmail(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewCustomerModal(false)}
                  className="px-3 py-1.5 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-sky-600 text-white rounded-lg hover:bg-sky-700 font-semibold shadow-xs"
                >
                  Save & Select
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINTABLE INVOICE MODAL */}
      {savedInvoiceForPrint && settings && (
        <PrintableInvoice
          invoice={savedInvoiceForPrint}
          settings={settings}
          onClose={() => setSavedInvoiceForPrint(null)}
        />
      )}
    </div>
  );
};
