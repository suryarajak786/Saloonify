import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar, ActivePage } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardPage } from './pages/DashboardPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { PosBillingPage } from './pages/PosBillingPage';
import { CustomersPage } from './pages/CustomersPage';
import { ServicesPage } from './pages/ServicesPage';
import { StaffPage } from './pages/StaffPage';
import { InventoryPage } from './pages/InventoryPage';
import { ExpensesPage } from './pages/ExpensesPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { LoginPage } from './pages/LoginPage';
import { Appointment } from './types';
import { api } from './services/api';
import { RefreshCw } from 'lucide-react';

function SaloonifyApp() {
  const { isAuthenticated, isLoading } = useAuth();
  const [activePage, setActivePage] = useState<ActivePage>('dashboard');
  const [dbStatus, setDbStatus] = useState<{ isMysql: boolean; engine: string } | null>(null);
  const [posAppointment, setPosAppointment] = useState<Appointment | null>(null);

  const fetchDbStatus = async () => {
    try {
      const res = await api.getHealth();
      if (res.success && res.database) {
        setDbStatus({
          isMysql: res.database.isMysql || false,
          engine: res.database.engine,
        });
      }
    } catch {
      // offline or loading
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchDbStatus();
    }
  }, [isAuthenticated]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-500">
          <RefreshCw className="w-7 h-7 animate-spin text-sky-600" />
          <span className="text-xs font-semibold tracking-wide">Starting Saloonify Operations System...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const handleBillAppointment = (apt: Appointment) => {
    setPosAppointment(apt);
    setActivePage('pos');
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        isMysql={dbStatus?.isMysql}
        dbEngine={dbStatus?.engine}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header Contract */}
        <Header
          activePage={activePage}
          onOpenNewAppointment={() => setActivePage('appointments')}
          onOpenNewBill={() => {
            setPosAppointment(null);
            setActivePage('pos');
          }}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto">
          {activePage === 'dashboard' && (
            <DashboardPage
              onNavigate={(page) => setActivePage(page)}
              onOpenBillForAppointment={handleBillAppointment}
            />
          )}

          {activePage === 'appointments' && (
            <AppointmentsPage onBillAtPos={handleBillAppointment} />
          )}

          {activePage === 'pos' && (
            <PosBillingPage
              initialAppointment={posAppointment}
              onClearInitialAppointment={() => setPosAppointment(null)}
            />
          )}

          {activePage === 'customers' && (
            <CustomersPage
              onStartPosBill={(cust) => {
                setActivePage('pos');
              }}
            />
          )}

          {activePage === 'services' && <ServicesPage />}

          {activePage === 'staff' && <StaffPage />}

          {activePage === 'inventory' && <InventoryPage />}

          {activePage === 'expenses' && <ExpensesPage />}

          {activePage === 'reports' && <ReportsPage />}

          {activePage === 'settings' && (
            <SettingsPage onDataReset={fetchDbStatus} />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SaloonifyApp />
    </AuthProvider>
  );
}
