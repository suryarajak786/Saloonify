import React from 'react';
import {
  LayoutDashboard,
  CalendarDays,
  ReceiptText,
  Users2,
  Scissors,
  UserCheck,
  Package,
  CreditCard,
  BarChart3,
  Settings as SettingsIcon,
  Database,
} from 'lucide-react';

export type ActivePage =
  | 'dashboard'
  | 'appointments'
  | 'pos'
  | 'customers'
  | 'services'
  | 'staff'
  | 'inventory'
  | 'expenses'
  | 'reports'
  | 'settings';

interface SidebarProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  dbEngine?: string;
  isMysql?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  setActivePage,
  dbEngine = 'MySQL Community Server',
  isMysql = true,
}) => {
  const isConnected = isMysql;
  const navItems: Array<{ id: ActivePage; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'appointments', label: 'Appointments', icon: CalendarDays },
    { id: 'pos', label: 'Billing / POS', icon: ReceiptText },
    { id: 'customers', label: 'Customers', icon: Users2 },
    { id: 'services', label: 'Services & Pricing', icon: Scissors },
    { id: 'staff', label: 'Staff Management', icon: UserCheck },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'expenses', label: 'Expenses', icon: CreditCard },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Salon Settings', icon: SettingsIcon },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center gap-3 px-6 border-b border-slate-200">
        <img
          src="/src/assets/images/saloonify_logo_mark_1792068954558.jpg"
          alt="Saloonify Logo"
          className="w-8 h-8 rounded-lg object-contain border border-slate-200/80 shadow-2xs"
        />
        <div className="flex flex-col">
          <span className="font-bold text-base tracking-tight text-slate-900 leading-none">Saloonify</span>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5">Salon Operations</span>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActivePage(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors text-left ${
                isActive
                  ? 'bg-sky-50 text-sky-800 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-600' : 'text-slate-400'}`} />
              <span className="whitespace-nowrap truncate">{item.label}</span>
              {isActive && (
                <span className="ml-auto w-1.5 h-1.5 rounded-full bg-sky-600 shrink-0" aria-hidden="true" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info & DB Status */}
      <div className="p-4 border-t border-slate-200 bg-slate-50/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-600">
            <Database className="w-3.5 h-3.5 text-sky-600 shrink-0" />
            <span className="truncate max-w-[130px] font-medium text-slate-800">MySQL Database</span>
          </div>
          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
            {isConnected ? 'CONNECTED' : 'DISCONNECTED'}
          </span>
        </div>
      </div>
    </aside>
  );
};
