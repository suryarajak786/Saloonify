import mysql, { Pool, PoolConnection } from 'mysql2/promise';
import { MYSQL_TABLE_DDL } from './models/schemas.js';

let pool: Pool | null = null;
let isMysqlConnected = false;
let connectionError: string | null = null;

export async function initDatabase(): Promise<{ isMysql: boolean; message: string }> {
  const host = process.env.MYSQL_HOST || '127.0.0.1';
  const port = process.env.MYSQL_PORT ? parseInt(process.env.MYSQL_PORT) : 3306;
  const database = process.env.MYSQL_DATABASE || 'saloonify';

  const credentialCandidates = [
    {
      user: process.env.MYSQL_USER || 'saloonify',
      password: process.env.MYSQL_PASSWORD !== undefined ? process.env.MYSQL_PASSWORD : 'saloonify123',
    },
    { user: 'root', password: process.env.MYSQL_PASSWORD || 'Pothumm@n1' },
    { user: 'saloonify', password: 'saloonify123' },
    { user: 'root', password: '' },
  ];

  let lastError: any = null;

  for (const cred of credentialCandidates) {
    try {
      console.log(`[Saloonify DB] Attempting MySQL connection to ${host}:${port}/${database} as user '${cred.user}'...`);

      const candidatePool = mysql.createPool({
        host,
        port,
        user: cred.user,
        password: cred.password,
        database,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        multipleStatements: true,
        dateStrings: true,
      });

      // Test ping connection
      const testConn = await candidatePool.getConnection();
      await testConn.ping();
      testConn.release();

      pool = candidatePool;
      break;
    } catch (err: any) {
      lastError = err;
      console.warn(`[Saloonify DB] Connection attempt as '${cred.user}' failed: ${err.message}`);
    }
  }

  if (!pool) {
    isMysqlConnected = false;
    connectionError = lastError?.message || 'MySQL Connection Failed';
    console.error(`[Saloonify DB ERROR] Failed to connect to MySQL with any credentials:`, lastError?.message);
    throw new Error(`Database connection failed: ${lastError?.message}. Ensure MySQL is running on port ${port} and database '${database}' exists.`);
  }

  try {
    // Execute table migrations
    await pool.query(MYSQL_TABLE_DDL);

    // Ensure default settings row exists if completely empty
    const [settingRows]: any = await pool.query('SELECT COUNT(*) as cnt FROM settings');
    if (settingRows[0].cnt === 0) {
      await pool.query(`
        INSERT INTO settings (
          id, salon_name, tagline, phone, email, address, city, state, pincode,
          gstin, default_gst_rate, tax_mode, currency_symbol, invoice_prefix,
          invoice_footer, terms_and_conditions, operating_hours
        ) VALUES (
          'set_default',
          'Saloonify Luxury Salon & Spa',
          'Style, Care & Elegance Redefined',
          '+91 98765 43210',
          'care@saloonify.in',
          '#42, 100 Feet Road, Indiranagar',
          'Bengaluru',
          'Karnataka',
          '560038',
          '29ABCDE1234F1Z5',
          18,
          'exclusive',
          '₹',
          'INV',
          'Thank you for visiting Saloonify! We look forward to seeing you again.',
          'Services once billed cannot be refunded. Please present this invoice for any adjustments within 48 hours.',
          ?
        )
      `, [JSON.stringify({
        open: '09:00',
        close: '21:00',
        workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
      })]);
    }

    isMysqlConnected = true;
    connectionError = null;
    const msg = `Connected successfully to MySQL database '${database}' on ${host}:${port}. Tables verified.`;
    console.log(`[Saloonify DB] ${msg}`);
    return { isMysql: true, message: msg };
  } catch (err: any) {
    isMysqlConnected = false;
    connectionError = err.message || 'MySQL Connection Failed';
    console.error(`[Saloonify DB ERROR] Failed to connect to MySQL:`, err.message);
    throw new Error(`Database connection failed: ${err.message}. Ensure MySQL is running and credentials in .env are correct.`);
  }
}

function getPool(): Pool {
  if (!pool) {
    throw new Error('Database pool not initialized. Please ensure MySQL is running.');
  }
  return pool;
}

// Helper to normalize MySQL field names to camelCase for API compatibility
function mapRow(row: any): any {
  if (!row) return null;
  const mapped: any = { _id: row.id, ...row };

  // Common JSON fields parsing
  if (row.specialties && typeof row.specialties === 'string') {
    try { mapped.specialties = JSON.parse(row.specialties); } catch { mapped.specialties = []; }
  }
  if (row.schedule && typeof row.schedule === 'string') {
    try { mapped.schedule = JSON.parse(row.schedule); } catch { mapped.schedule = null; }
  }
  if (row.services && typeof row.services === 'string') {
    try { mapped.services = JSON.parse(row.services); } catch { mapped.services = []; }
  }
  if (row.items && typeof row.items === 'string') {
    try { mapped.items = JSON.parse(row.items); } catch { mapped.items = []; }
  }
  if (row.operating_hours && typeof row.operating_hours === 'string') {
    try { mapped.operatingHours = JSON.parse(row.operating_hours); } catch { mapped.operatingHours = null; }
  }

  // Common snake_case to camelCase
  if (row.appointment_number !== undefined) mapped.appointmentNumber = row.appointment_number;
  if (row.customer_id !== undefined) mapped.customerId = row.customer_id;
  if (row.customer_name !== undefined) mapped.customerName = row.customer_name;
  if (row.customer_phone !== undefined) mapped.customerPhone = row.customer_phone;
  if (row.customer_address !== undefined) mapped.customerAddress = row.customer_address;
  if (row.staff_id !== undefined) mapped.staffId = row.staff_id;
  if (row.staff_name !== undefined) mapped.staffName = row.staff_name;
  if (row.appointment_id !== undefined) mapped.appointmentId = row.appointment_id;
  if (row.appointment_date !== undefined) mapped.appointmentDate = row.appointment_date;
  if (row.start_time !== undefined) mapped.startTime = row.start_time;
  if (row.end_time !== undefined) mapped.endTime = row.end_time;
  if (row.total_amount !== undefined) mapped.totalAmount = Number(row.total_amount);
  if (row.invoice_number !== undefined) mapped.invoiceNumber = row.invoice_number;
  if (row.discount_amount !== undefined) mapped.discountAmount = Number(row.discount_amount);
  if (row.taxable_amount !== undefined) mapped.taxableAmount = Number(row.taxable_amount);
  if (row.cgst_total !== undefined) mapped.cgstTotal = Number(row.cgst_total);
  if (row.sgst_total !== undefined) mapped.sgstTotal = Number(row.sgst_total);
  if (row.total_tax !== undefined) mapped.totalTax = Number(row.total_tax);
  if (row.grand_total !== undefined) mapped.grandTotal = Number(row.grand_total);
  if (row.round_off !== undefined) mapped.roundOff = Number(row.round_off);
  if (row.paid_amount !== undefined) mapped.paidAmount = Number(row.paid_amount);
  if (row.due_amount !== undefined) mapped.dueAmount = Number(row.due_amount);
  if (row.payment_method !== undefined) mapped.paymentMethod = row.payment_method;
  if (row.payment_status !== undefined) mapped.paymentStatus = row.payment_status;
  if (row.tax_mode !== undefined) mapped.taxMode = row.tax_mode;
  if (row.duration_minutes !== undefined) mapped.durationMinutes = Number(row.duration_minutes);
  if (row.tax_rate !== undefined) mapped.taxRate = Number(row.tax_rate);
  if (row.is_active !== undefined) mapped.isActive = Boolean(row.is_active);
  if (row.gender_target !== undefined) mapped.genderTarget = row.gender_target;
  if (row.purchase_cost !== undefined) mapped.purchaseCost = Number(row.purchase_cost);
  if (row.selling_price !== undefined) mapped.sellingPrice = Number(row.selling_price);
  if (row.stock_quantity !== undefined) mapped.stockQuantity = Number(row.stock_quantity);
  if (row.min_stock_threshold !== undefined) mapped.minStockThreshold = Number(row.min_stock_threshold);
  if (row.product_id !== undefined) mapped.productId = row.product_id;
  if (row.product_name !== undefined) mapped.productName = row.product_name;
  if (row.previous_stock !== undefined) mapped.previousStock = Number(row.previous_stock);
  if (row.new_stock !== undefined) mapped.newStock = Number(row.new_stock);
  if (row.performed_by !== undefined) mapped.performedBy = row.performed_by;
  if (row.receipt_number !== undefined) mapped.receiptNumber = row.receipt_number;
  if (row.paid_to !== undefined) mapped.paidTo = row.paid_to;
  if (row.total_visits !== undefined) mapped.totalVisits = Number(row.total_visits);
  if (row.total_spent !== undefined) mapped.totalSpent = Number(row.total_spent);
  if (row.last_visit_date !== undefined) mapped.lastVisitDate = row.last_visit_date;
  if (row.commission_percentage !== undefined) mapped.commissionPercentage = Number(row.commission_percentage);
  if (row.salon_name !== undefined) mapped.salonName = row.salon_name;
  if (row.default_gst_rate !== undefined) mapped.defaultGstRate = Number(row.default_gst_rate);
  if (row.currency_symbol !== undefined) mapped.currencySymbol = row.currency_symbol;
  if (row.invoice_prefix !== undefined) mapped.invoicePrefix = row.invoice_prefix;
  if (row.invoice_footer !== undefined) mapped.invoiceFooter = row.invoice_footer;
  if (row.terms_and_conditions !== undefined) mapped.termsAndConditions = row.terms_and_conditions;
  if (row.subtotal !== undefined) mapped.subtotal = Number(row.subtotal);
  if (row.price !== undefined) mapped.price = Number(row.price);
  if (row.amount !== undefined) mapped.amount = Number(row.amount);

  return mapped;
}

export const db = {
  isMysqlConnected: () => isMysqlConnected,
  getConnectionStatus: () => ({
    isMysql: isMysqlConnected,
    engine: 'MySQL Community Server',
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: process.env.MYSQL_PORT || 3306,
    database: process.env.MYSQL_DATABASE || 'saloonify',
    error: connectionError,
  }),
  getPool,

  // Direct query executor
  async query(sql: string, params: any[] = []): Promise<any> {
    const p = getPool();
    const [results] = await p.query(sql, params);
    return results;
  },

  // USERS REPOSITORY
  users: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM users');
      return Number(rows[0].count);
    },
    async find(): Promise<any[]> {
      const [rows]: any = await getPool().query('SELECT * FROM users ORDER BY created_at DESC');
      return rows.map(mapRow);
    },
    async findOne(filter: { email?: string; id?: string }): Promise<any | null> {
      if (filter.email) {
        const [rows]: any = await getPool().query('SELECT * FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1', [filter.email.trim()]);
        return rows[0] ? mapRow(rows[0]) : null;
      }
      if (filter.id) {
        const [rows]: any = await getPool().query('SELECT * FROM users WHERE id = ? LIMIT 1', [filter.id]);
        return rows[0] ? mapRow(rows[0]) : null;
      }
      return null;
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM users WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        'INSERT INTO users (id, name, email, password, role, phone, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [id, data.name.trim(), data.email.toLowerCase().trim(), data.password, data.role || 'staff', data.phone || '', data.avatar || '']
      );
      return this.findById(id);
    }
  },

  // STAFF REPOSITORY
  staff: {
    async find(filters?: any): Promise<any[]> {
      const [rows]: any = await getPool().query('SELECT * FROM staff ORDER BY name ASC');
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM staff WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `stf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        'INSERT INTO staff (id, name, phone, email, role, specialties, commission_percentage, avatar, is_active, schedule) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          id,
          data.name.trim(),
          data.phone.trim(),
          data.email ? data.email.trim() : '',
          data.role.trim(),
          JSON.stringify(Array.isArray(data.specialties) ? data.specialties : []),
          Number(data.commissionPercentage) || 0,
          data.avatar || '',
          data.isActive !== false ? 1 : 0,
          JSON.stringify(data.schedule || { days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], shiftStart: '10:00', shiftEnd: '19:00' })
        ]
      );
      return this.findById(id);
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any | null> {
      const existing = await this.findById(id);
      if (!existing) return null;

      const name = data.name !== undefined ? data.name.trim() : existing.name;
      const phone = data.phone !== undefined ? data.phone.trim() : existing.phone;
      const email = data.email !== undefined ? data.email.trim() : existing.email;
      const role = data.role !== undefined ? data.role.trim() : existing.role;
      const specialties = data.specialties !== undefined ? JSON.stringify(data.specialties) : JSON.stringify(existing.specialties || []);
      const comm = data.commissionPercentage !== undefined ? Number(data.commissionPercentage) : existing.commissionPercentage;
      const avatar = data.avatar !== undefined ? data.avatar : existing.avatar;
      const isActive = data.isActive !== undefined ? (data.isActive ? 1 : 0) : (existing.isActive ? 1 : 0);
      const schedule = data.schedule !== undefined ? JSON.stringify(data.schedule) : JSON.stringify(existing.schedule);

      await getPool().query(
        'UPDATE staff SET name = ?, phone = ?, email = ?, role = ?, specialties = ?, commission_percentage = ?, avatar = ?, is_active = ?, schedule = ? WHERE id = ?',
        [name, phone, email, role, specialties, comm, avatar, isActive, schedule, id]
      );
      return this.findById(id);
    },
    async findByIdAndDelete(id: string): Promise<boolean> {
      const [res]: any = await getPool().query('DELETE FROM staff WHERE id = ?', [id]);
      return res.affectedRows > 0;
    }
  },

  // CUSTOMERS REPOSITORY
  customers: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM customers');
      return Number(rows[0].count);
    },
    async find(search?: string): Promise<any[]> {
      if (search && search.trim()) {
        const q = `%${search.trim().toLowerCase()}%`;
        const [rows]: any = await getPool().query(
          'SELECT * FROM customers WHERE LOWER(name) LIKE ? OR phone LIKE ? OR LOWER(email) LIKE ? ORDER BY created_at DESC',
          [q, q, q]
        );
        return rows.map(mapRow);
      }
      const [rows]: any = await getPool().query('SELECT * FROM customers ORDER BY created_at DESC');
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM customers WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async findOne(filter: { phone?: string; id?: string }): Promise<any | null> {
      if (filter.phone) {
        const [rows]: any = await getPool().query('SELECT * FROM customers WHERE phone = ? LIMIT 1', [filter.phone.trim()]);
        return rows[0] ? mapRow(rows[0]) : null;
      }
      if (filter.id) {
        return this.findById(filter.id);
      }
      return null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `cst_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        `INSERT INTO customers (
          id, name, phone, email, gender, birthdate, anniversary,
          address, notes, preferences, total_visits, total_spent, last_visit_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          data.name.trim(),
          data.phone.trim(),
          data.email ? data.email.trim() : '',
          data.gender || 'female',
          data.birthdate || '',
          data.anniversary || '',
          data.address ? data.address.trim() : '',
          data.notes ? data.notes.trim() : '',
          data.preferences ? data.preferences.trim() : '',
          Number(data.totalVisits) || 0,
          Number(data.totalSpent) || 0,
          data.lastVisitDate || ''
        ]
      );
      return this.findById(id);
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any | null> {
      const existing = await this.findById(id);
      if (!existing) return null;

      const name = data.name !== undefined ? data.name.trim() : existing.name;
      const phone = data.phone !== undefined ? data.phone.trim() : existing.phone;
      const email = data.email !== undefined ? data.email.trim() : existing.email;
      const gender = data.gender !== undefined ? data.gender : existing.gender;
      const birthdate = data.birthdate !== undefined ? data.birthdate : existing.birthdate;
      const anniversary = data.anniversary !== undefined ? data.anniversary : existing.anniversary;
      const address = data.address !== undefined ? data.address.trim() : existing.address;
      const notes = data.notes !== undefined ? data.notes.trim() : existing.notes;
      const preferences = data.preferences !== undefined ? data.preferences.trim() : existing.preferences;
      const totalVisits = data.totalVisits !== undefined ? Number(data.totalVisits) : existing.totalVisits;
      const totalSpent = data.totalSpent !== undefined ? Number(data.totalSpent) : existing.totalSpent;
      const lastVisitDate = data.lastVisitDate !== undefined ? data.lastVisitDate : existing.lastVisitDate;

      await getPool().query(
        `UPDATE customers SET
          name = ?, phone = ?, email = ?, gender = ?, birthdate = ?, anniversary = ?,
          address = ?, notes = ?, preferences = ?, total_visits = ?, total_spent = ?, last_visit_date = ?
        WHERE id = ?`,
        [name, phone, email, gender, birthdate, anniversary, address, notes, preferences, totalVisits, totalSpent, lastVisitDate, id]
      );
      return this.findById(id);
    },
    async findByIdAndDelete(id: string): Promise<boolean> {
      const [res]: any = await getPool().query('DELETE FROM customers WHERE id = ?', [id]);
      return res.affectedRows > 0;
    }
  },

  // SERVICES REPOSITORY
  services: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM services');
      return Number(rows[0].count);
    },
    async find(category?: string, search?: string, activeOnly: boolean = false): Promise<any[]> {
      let query = 'SELECT * FROM services WHERE 1=1';
      const params: any[] = [];

      if (activeOnly) {
        query += ' AND is_active = 1';
      }
      if (category && category !== 'All') {
        query += ' AND category = ?';
        params.push(category);
      }
      if (search && search.trim()) {
        query += ' AND (LOWER(name) LIKE ? OR LOWER(category) LIKE ? OR LOWER(description) LIKE ?)';
        const q = `%${search.trim().toLowerCase()}%`;
        params.push(q, q, q);
      }

      query += ' ORDER BY category ASC, name ASC';
      const [rows]: any = await getPool().query(query, params);
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM services WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `srv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        'INSERT INTO services (id, name, category, description, price, duration_minutes, tax_rate, is_active, gender_target) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          id,
          data.name.trim(),
          data.category || 'Hair Care',
          data.description ? data.description.trim() : '',
          Number(data.price),
          Number(data.durationMinutes),
          data.taxRate !== undefined ? Number(data.taxRate) : 18,
          data.isActive !== false ? 1 : 0,
          data.genderTarget || 'all'
        ]
      );
      return this.findById(id);
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any | null> {
      const existing = await this.findById(id);
      if (!existing) return null;

      const name = data.name !== undefined ? data.name.trim() : existing.name;
      const category = data.category !== undefined ? data.category : existing.category;
      const description = data.description !== undefined ? data.description.trim() : existing.description;
      const price = data.price !== undefined ? Number(data.price) : existing.price;
      const duration = data.durationMinutes !== undefined ? Number(data.durationMinutes) : existing.durationMinutes;
      const taxRate = data.taxRate !== undefined ? Number(data.taxRate) : existing.taxRate;
      const isActive = data.isActive !== undefined ? (data.isActive ? 1 : 0) : (existing.isActive ? 1 : 0);
      const genderTarget = data.genderTarget !== undefined ? data.genderTarget : existing.genderTarget;

      await getPool().query(
        'UPDATE services SET name = ?, category = ?, description = ?, price = ?, duration_minutes = ?, tax_rate = ?, is_active = ?, gender_target = ? WHERE id = ?',
        [name, category, description, price, duration, taxRate, isActive, genderTarget, id]
      );
      return this.findById(id);
    },
    async findByIdAndDelete(id: string): Promise<boolean> {
      const [res]: any = await getPool().query('DELETE FROM services WHERE id = ?', [id]);
      return res.affectedRows > 0;
    }
  },

  // APPOINTMENTS REPOSITORY
  appointments: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM appointments');
      return Number(rows[0].count);
    },
    async find(filters: { date?: string; staffId?: string; customerId?: string; status?: string } = {}): Promise<any[]> {
      let query = 'SELECT * FROM appointments WHERE 1=1';
      const params: any[] = [];

      if (filters.date) {
        query += ' AND appointment_date = ?';
        params.push(filters.date);
      }
      if (filters.staffId && filters.staffId !== 'all') {
        query += ' AND staff_id = ?';
        params.push(filters.staffId);
      }
      if (filters.customerId) {
        query += ' AND customer_id = ?';
        params.push(filters.customerId);
      }
      if (filters.status && filters.status !== 'all') {
        query += ' AND status = ?';
        params.push(filters.status);
      }

      query += ' ORDER BY appointment_date ASC, start_time ASC';
      const [rows]: any = await getPool().query(query, params);
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM appointments WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `apt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        `INSERT INTO appointments (
          id, appointment_number, customer_id, customer_name, customer_phone,
          staff_id, staff_name, services, appointment_date, start_time, end_time,
          status, notes, total_amount
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          data.appointmentNumber,
          data.customerId,
          data.customerName,
          data.customerPhone,
          data.staffId,
          data.staffName,
          JSON.stringify(data.services || []),
          data.appointmentDate,
          data.startTime,
          data.endTime,
          data.status || 'booked',
          data.notes || '',
          Number(data.totalAmount) || 0
        ]
      );
      return this.findById(id);
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any | null> {
      const existing = await this.findById(id);
      if (!existing) return null;

      const status = data.status !== undefined ? data.status : existing.status;
      const date = data.appointmentDate !== undefined ? data.appointmentDate : existing.appointmentDate;
      const start = data.startTime !== undefined ? data.startTime : existing.startTime;
      const end = data.endTime !== undefined ? data.endTime : existing.endTime;
      const staffId = data.staffId !== undefined ? data.staffId : existing.staffId;
      const staffName = data.staffName !== undefined ? data.staffName : existing.staffName;
      const notes = data.notes !== undefined ? data.notes : existing.notes;
      const totalAmount = data.totalAmount !== undefined ? Number(data.totalAmount) : existing.totalAmount;
      const services = data.services !== undefined ? JSON.stringify(data.services) : JSON.stringify(existing.services);

      await getPool().query(
        `UPDATE appointments SET
          status = ?, appointment_date = ?, start_time = ?, end_time = ?,
          staff_id = ?, staff_name = ?, notes = ?, total_amount = ?, services = ?
        WHERE id = ?`,
        [status, date, start, end, staffId, staffName, notes, totalAmount, services, id]
      );
      return this.findById(id);
    },
    async findByIdAndDelete(id: string): Promise<boolean> {
      const [res]: any = await getPool().query('DELETE FROM appointments WHERE id = ?', [id]);
      return res.affectedRows > 0;
    }
  },

  // INVOICES REPOSITORY WITH TRANSACTION SUPPORT
  invoices: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM invoices');
      return Number(rows[0].count);
    },
    async find(filters: { startDate?: string; endDate?: string; paymentMethod?: string; customerId?: string; search?: string } = {}): Promise<any[]> {
      let query = 'SELECT * FROM invoices WHERE 1=1';
      const params: any[] = [];

      if (filters.startDate) {
        query += ' AND date >= ?';
        params.push(filters.startDate);
      }
      if (filters.endDate) {
        query += ' AND date <= ?';
        params.push(`${filters.endDate}T23:59:59.999Z`);
      }
      if (filters.paymentMethod && filters.paymentMethod !== 'all') {
        query += ' AND payment_method = ?';
        params.push(filters.paymentMethod);
      }
      if (filters.customerId) {
        query += ' AND customer_id = ?';
        params.push(filters.customerId);
      }
      if (filters.search && filters.search.trim()) {
        const q = `%${filters.search.trim().toLowerCase()}%`;
        query += ' AND (LOWER(invoice_number) LIKE ? OR LOWER(customer_name) LIKE ? OR customer_phone LIKE ?)';
        params.push(q, q, q);
      }

      query += ' ORDER BY date DESC';
      const [rows]: any = await getPool().query(query, params);
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM invoices WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async findByInvoiceNumber(invNum: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM invoices WHERE invoice_number = ? LIMIT 1', [invNum]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      return this.createWithTransaction(data);
    },

    // Transaction-based invoice creation: records invoice, updates customer stats, decrements product inventory, logs inventory movement
    async createWithTransaction(data: any): Promise<any> {
      const conn: PoolConnection = await getPool().getConnection();
      try {
        await conn.beginTransaction();

        const id = data.id || `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

        await conn.query(
          `INSERT INTO invoices (
            id, invoice_number, customer_id, customer_name, customer_phone, customer_address,
            staff_id, staff_name, appointment_id, date, items, subtotal, discount_amount,
            taxable_amount, cgst_total, sgst_total, total_tax, grand_total, round_off,
            payment_method, payment_status, paid_amount, due_amount, tax_mode, notes
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id,
            data.invoiceNumber,
            data.customerId,
            data.customerName,
            data.customerPhone,
            data.customerAddress || '',
            data.staffId || '',
            data.staffName || '',
            data.appointmentId || '',
            data.date,
            JSON.stringify(data.items || []),
            Number(data.subtotal) || 0,
            Number(data.discountAmount) || 0,
            Number(data.taxableAmount) || 0,
            Number(data.cgstTotal) || 0,
            Number(data.sgstTotal) || 0,
            Number(data.totalTax) || 0,
            Number(data.grandTotal) || 0,
            Number(data.roundOff) || 0,
            data.paymentMethod || 'cash',
            data.paymentStatus || 'paid',
            Number(data.paidAmount) || 0,
            Number(data.dueAmount) || 0,
            data.taxMode || 'exclusive',
            data.notes || ''
          ]
        );

        // Update customer statistics in MySQL
        await conn.query(
          `UPDATE customers SET
            total_visits = total_visits + 1,
            total_spent = total_spent + ?,
            last_visit_date = ?
          WHERE id = ?`,
          [Number(data.grandTotal) || 0, data.date.split('T')[0], data.customerId]
        );

        // Handle retail products: deduct stock and record inventory movement
        for (const item of data.items) {
          if (item.itemType === 'product' && item.itemId) {
            const [prodRows]: any = await conn.query('SELECT * FROM products WHERE id = ? FOR UPDATE', [item.itemId]);
            if (prodRows && prodRows.length > 0) {
              const currentStock = Number(prodRows[0].stock_quantity);
              const qty = Number(item.quantity) || 1;
              const newStock = Math.max(0, currentStock - qty);

              await conn.query('UPDATE products SET stock_quantity = ? WHERE id = ?', [newStock, item.itemId]);

              const movId = `mov_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
              await conn.query(
                `INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, previous_stock, new_stock, date, performed_by, notes)
                 VALUES (?, ?, ?, 'sale', ?, ?, ?, ?, ?, ?)`,
                [movId, item.itemId, prodRows[0].name, qty, currentStock, newStock, data.date, data.staffName || 'POS Register', `Invoice ${data.invoiceNumber}`]
              );
            }
          }
        }

        // If appointment was linked, mark as completed
        if (data.appointmentId) {
          await conn.query("UPDATE appointments SET status = 'completed' WHERE id = ?", [data.appointmentId]);
        }

        await conn.commit();

        const [created]: any = await getPool().query('SELECT * FROM invoices WHERE id = ? LIMIT 1', [id]);
        return mapRow(created[0]);
      } catch (err) {
        await conn.rollback();
        throw err;
      } finally {
        conn.release();
      }
    }
  },

  // PRODUCTS REPOSITORY
  products: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM products');
      return Number(rows[0].count);
    },
    async find(category?: string, search?: string): Promise<any[]> {
      let query = 'SELECT * FROM products WHERE 1=1';
      const params: any[] = [];

      if (category && category !== 'All') {
        query += ' AND category = ?';
        params.push(category);
      }
      if (search && search.trim()) {
        const q = `%${search.trim().toLowerCase()}%`;
        query += ' AND (LOWER(name) LIKE ? OR LOWER(sku) LIKE ? OR LOWER(category) LIKE ?)';
        params.push(q, q, q);
      }

      query += ' ORDER BY name ASC';
      const [rows]: any = await getPool().query(query, params);
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM products WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `prd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const sku = data.sku ? data.sku.trim() : `SKU-${Date.now().toString().slice(-6)}`;

      await getPool().query(
        `INSERT INTO products (
          id, name, sku, category, purchase_cost, selling_price, stock_quantity,
          min_stock_threshold, unit, supplier, tax_rate
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          data.name.trim(),
          sku,
          data.category || 'Retail Products',
          Number(data.purchaseCost),
          Number(data.sellingPrice),
          Number(data.stockQuantity) || 0,
          Number(data.minStockThreshold) || 5,
          data.unit || 'pcs',
          data.supplier ? data.supplier.trim() : '',
          data.taxRate !== undefined ? Number(data.taxRate) : 18
        ]
      );

      // If initial stock quantity was entered, record movement
      if (Number(data.stockQuantity) > 0) {
        const movId = `mov_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        await getPool().query(
          `INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, previous_stock, new_stock, date, performed_by, notes)
           VALUES (?, ?, ?, 'purchase', ?, 0, ?, ?, 'Initial Setup', 'Initial Stock Added')`,
          [movId, id, data.name.trim(), Number(data.stockQuantity), Number(data.stockQuantity), new Date().toISOString()]
        );
      }

      return this.findById(id);
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any | null> {
      const existing = await this.findById(id);
      if (!existing) return null;

      const name = data.name !== undefined ? data.name.trim() : existing.name;
      const sku = data.sku !== undefined ? data.sku.trim() : existing.sku;
      const category = data.category !== undefined ? data.category : existing.category;
      const purchaseCost = data.purchaseCost !== undefined ? Number(data.purchaseCost) : existing.purchaseCost;
      const sellingPrice = data.sellingPrice !== undefined ? Number(data.sellingPrice) : existing.sellingPrice;
      const stockQuantity = data.stockQuantity !== undefined ? Number(data.stockQuantity) : existing.stockQuantity;
      const minStock = data.minStockThreshold !== undefined ? Number(data.minStockThreshold) : existing.minStockThreshold;
      const unit = data.unit !== undefined ? data.unit : existing.unit;
      const supplier = data.supplier !== undefined ? data.supplier.trim() : existing.supplier;
      const taxRate = data.taxRate !== undefined ? Number(data.taxRate) : existing.taxRate;

      await getPool().query(
        `UPDATE products SET
          name = ?, sku = ?, category = ?, purchase_cost = ?, selling_price = ?,
          stock_quantity = ?, min_stock_threshold = ?, unit = ?, supplier = ?, tax_rate = ?
        WHERE id = ?`,
        [name, sku, category, purchaseCost, sellingPrice, stockQuantity, minStock, unit, supplier, taxRate, id]
      );
      return this.findById(id);
    },
    async adjustStock(id: string, type: string, quantity: number, notes: string = '', performedBy: string = 'Staff'): Promise<any> {
      const conn: PoolConnection = await getPool().getConnection();
      try {
        await conn.beginTransaction();

        const [rows]: any = await conn.query('SELECT * FROM products WHERE id = ? FOR UPDATE', [id]);
        if (!rows || rows.length === 0) throw new Error('Product not found');

        const prevStock = Number(rows[0].stock_quantity);
        let newStock = prevStock;

        if (type === 'purchase') {
          newStock = prevStock + quantity;
        } else if (type === 'internal_use' || type === 'sale') {
          newStock = Math.max(0, prevStock - quantity);
        } else if (type === 'adjustment') {
          newStock = quantity;
        }

        await conn.query('UPDATE products SET stock_quantity = ? WHERE id = ?', [newStock, id]);

        const movId = `mov_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        await conn.query(
          `INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, previous_stock, new_stock, date, performed_by, notes)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [movId, id, rows[0].name, type, quantity, prevStock, newStock, new Date().toISOString(), performedBy, notes]
        );

        await conn.commit();
        return { newStock, movementId: movId };
      } catch (err) {
        await conn.rollback();
        throw err;
      } finally {
        conn.release();
      }
    }
  },

  // INVENTORY MOVEMENTS REPOSITORY
  inventoryMovements: {
    async find(limit: number = 100): Promise<any[]> {
      const [rows]: any = await getPool().query('SELECT * FROM inventory_movements ORDER BY date DESC LIMIT ?', [limit]);
      return rows.map(mapRow);
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `mov_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        'INSERT INTO inventory_movements (id, product_id, product_name, type, quantity, previous_stock, new_stock, date, performed_by, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          id,
          data.productId,
          data.productName,
          data.type,
          Number(data.quantity),
          Number(data.previousStock),
          Number(data.newStock),
          data.date || new Date().toISOString(),
          data.performedBy || 'Staff',
          data.notes || ''
        ]
      );
      const [rows]: any = await getPool().query('SELECT * FROM inventory_movements WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    }
  },

  // EXPENSES REPOSITORY
  expenses: {
    async countDocuments(): Promise<number> {
      const [rows]: any = await getPool().query('SELECT COUNT(*) as count FROM expenses');
      return Number(rows[0].count);
    },
    async find(category?: string, startDate?: string, endDate?: string): Promise<any[]> {
      let query = 'SELECT * FROM expenses WHERE 1=1';
      const params: any[] = [];

      if (category && category !== 'All') {
        query += ' AND category = ?';
        params.push(category);
      }
      if (startDate) {
        query += ' AND date >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND date <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY date DESC';
      const [rows]: any = await getPool().query(query, params);
      return rows.map(mapRow);
    },
    async findById(id: string): Promise<any | null> {
      const [rows]: any = await getPool().query('SELECT * FROM expenses WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async create(data: any): Promise<any> {
      const id = data.id || data._id || `exp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await getPool().query(
        'INSERT INTO expenses (id, title, category, amount, date, payment_method, paid_to, receipt_number, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          id,
          data.title.trim(),
          data.category || 'Miscellaneous',
          Number(data.amount),
          data.date || new Date().toISOString().split('T')[0],
          data.paymentMethod || 'cash',
          data.paidTo ? data.paidTo.trim() : '',
          data.receiptNumber ? data.receiptNumber.trim() : '',
          data.notes ? data.notes.trim() : ''
        ]
      );
      return this.findById(id);
    },
    async findByIdAndDelete(id: string): Promise<boolean> {
      const [res]: any = await getPool().query('DELETE FROM expenses WHERE id = ?', [id]);
      return res.affectedRows > 0;
    }
  },

  // SETTINGS REPOSITORY
  settings: {
    async get(): Promise<any> {
      const [rows]: any = await getPool().query('SELECT * FROM settings LIMIT 1');
      return rows[0] ? mapRow(rows[0]) : null;
    },
    async update(data: any): Promise<any> {
      const current = await this.get();
      if (!current) throw new Error('Settings row not found');

      const salonName = data.salonName !== undefined ? data.salonName.trim() : current.salonName;
      const tagline = data.tagline !== undefined ? data.tagline.trim() : current.tagline;
      const phone = data.phone !== undefined ? data.phone.trim() : current.phone;
      const email = data.email !== undefined ? data.email.trim() : current.email;
      const address = data.address !== undefined ? data.address.trim() : current.address;
      const city = data.city !== undefined ? data.city.trim() : current.city;
      const state = data.state !== undefined ? data.state.trim() : current.state;
      const pincode = data.pincode !== undefined ? data.pincode.trim() : current.pincode;
      const gstin = data.gstin !== undefined ? data.gstin.trim() : current.gstin;
      const defaultGstRate = data.defaultGstRate !== undefined ? Number(data.defaultGstRate) : current.defaultGstRate;
      const taxMode = data.taxMode !== undefined ? data.taxMode : (current.taxMode || 'exclusive');
      const currencySymbol = data.currencySymbol !== undefined ? data.currencySymbol : current.currencySymbol;
      const invoicePrefix = data.invoicePrefix !== undefined ? data.invoicePrefix.trim() : current.invoicePrefix;
      const invoiceFooter = data.invoiceFooter !== undefined ? data.invoiceFooter.trim() : current.invoiceFooter;
      const termsAndConditions = data.termsAndConditions !== undefined ? data.termsAndConditions.trim() : current.termsAndConditions;
      const operatingHours = data.operatingHours !== undefined ? JSON.stringify(data.operatingHours) : JSON.stringify(current.operatingHours || {});

      await getPool().query(
        `UPDATE settings SET
          salon_name = ?, tagline = ?, phone = ?, email = ?, address = ?, city = ?, state = ?, pincode = ?,
          gstin = ?, default_gst_rate = ?, tax_mode = ?, currency_symbol = ?, invoice_prefix = ?,
          invoice_footer = ?, terms_and_conditions = ?, operating_hours = ?
        WHERE id = ?`,
        [salonName, tagline, phone, email, address, city, state, pincode, gstin, defaultGstRate, taxMode, currencySymbol, invoicePrefix, invoiceFooter, termsAndConditions, operatingHours, current._id]
      );

      return this.get();
    },
    async find(filter?: any): Promise<any[]> {
      const s = await this.get();
      return s ? [s] : [];
    },
    async findByIdAndUpdate(id: string, data: any): Promise<any> {
      return this.update(data);
    },
    async create(data: any): Promise<any> {
      return this.update(data);
    }
  }
};
